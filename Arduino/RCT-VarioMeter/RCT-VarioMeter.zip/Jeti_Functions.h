// For any extra functions needed before loop()

// Reset sensor via Jetibox
void(* resetFunc) (void) = 0;